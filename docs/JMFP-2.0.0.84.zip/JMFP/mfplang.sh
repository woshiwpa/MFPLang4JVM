#!/bin/bash

# first of all, find out the real storing directory of the script.
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
    DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
    SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done

DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

if [ "$#" -eq 0 ]; then
    if [[ `uname -s` == MINGW* ]]; then # in mingwin, we need to convert to path to avoid unaccessible jar error.
        DIR=`cygpath -w "${DIR}"`
    elif [[ `uname -s` == CYGWIN* ]]; then # in cygwin, we need to convert to path to avoid unaccessible jar error.
        DIR=`cygpath -w "${DIR}"`
    fi
    java -jar "${DIR}"/JMFPLang.jar
else
    MFPSFILE="$1"
    if [[ `uname -s` == MINGW* ]]; then # in mingwin, we need to convert to path to avoid unaccessible jar error.
        DIR=`cygpath -w "${DIR}"`
        MFPSFILE=`cygpath -w "${MFPSFILE}"`
    elif [[ `uname -s` == CYGWIN* ]]; then # in cygwin, we need to convert to path to avoid unaccessible jar error.
        DIR=`cygpath -w "${DIR}"`
        MFPSFILE=`cygpath -w "${MFPSFILE}"`
    fi
    java -jar "${DIR}"/JMFPLang.jar -f "${MFPSFILE}" "${@:2}"
fi
